// Andre Surprenant  260751097
import java.io.Serializable;
import java.util.ArrayList;
import java.text.*;
import java.lang.Math;

public class DecisionTree implements Serializable {

	DTNode rootDTNode;
	int minSizeDatalist; //minimum number of datapoints that should be present in the dataset so as to initiate a split
	//Mention the serialVersionUID explicitly in order to avoid getting errors while deserializing.
	public static final long serialVersionUID = 343L;
	public DecisionTree(ArrayList<Datum> datalist , int min) {
		minSizeDatalist = min;
		rootDTNode = (new DTNode()).fillDTNode(datalist);
	}

	class DTNode implements Serializable{
		//Mention the serialVersionUID explicitly in order to avoid getting errors while deserializing.
		public static final long serialVersionUID = 438L;
		boolean leaf;
		int label = -1;      // only defined if node is a leaf
		int attribute; // only defined if node is not a leaf
		double threshold;  // only defined if node is not a leaf



		DTNode left, right; //the left and right child of a particular node. (null if leaf)

		DTNode() {
			leaf = true;
			threshold = Double.MAX_VALUE;
		}

		

		// this method takes in a datalist (ArrayList of type datum) and a minSizeInClassification (int) and returns
		// the calling DTNode object as the root of a decision tree trained using the datapoints present in the
		// datalist variable
		// Also, KEEP IN MIND that the left and right child of the node correspond to "less than" and "greater than or equal to" threshold

		DTNode fillDTNode(ArrayList<Datum> datalist) {
			
			//early stopping condition
			if(minSizeDatalist <= datalist.size()){
				//base case
				boolean allSame = true;
				for(Datum d : datalist) {
					if(datalist.get(0).y != d.y) {
						allSame = false;
						break;
					}
				}
				if(allSame) {
					this.leaf = true;
					this.label = datalist.get(0).y;
				}				
				else {		//recursive step
					//find the 'best' attribute/threshold pair
					double bestAvgEnt= Double.MAX_VALUE;
					int bestAttr = -1;
					double bestThresh = -1;
					
					//assuming # of attributes is 2 for all datums
					for(int i = 0; i < 2; i++) {
						for(Datum d1 : datalist) {
												
							ArrayList<Datum> subl= new ArrayList<Datum>();
							ArrayList<Datum> subg= new ArrayList<Datum>();
							
							for(Datum d2 : datalist) {
								
								if(d2.x[i] < d1.x[i]) {
									subl.add(d2);
								}else {
									subg.add(d2);
								}
								
							}
							// calculate average entropy for a particular attribute/threshold pair
							double omega1 = ((double) subl.size() )/((double) subl.size() + (double) subg.size());
							double omega2 = ((double) subg.size() )/((double) subl.size() + (double) subg.size());
							double curAvgEnt = omega1*calcEntropy(subl) + omega2*calcEntropy(subg);
							// here is where we update/train our tree
							if(curAvgEnt < bestAvgEnt) {	
								bestAvgEnt = curAvgEnt;
								bestAttr = i;
								bestThresh = d1.x[i];
							}	
						}
					}
					// create new node
					leaf = false;
					attribute = bestAttr;
					threshold = bestThresh;
					
					//fill the rest of the tree recursively
					ArrayList<Datum> data1 = new ArrayList<Datum>();
					ArrayList<Datum> data2 = new ArrayList<Datum>();
					for(Datum d : datalist) {
						if(d.x[bestAttr] < bestThresh) {
							data1.add(d);
						}else{
							data2.add(d);
						}
					}
					this.left = (new DTNode()).fillDTNode(data1);
					this.right = (new DTNode()).fillDTNode(data2);
				}
			}else {
				this.leaf = true;
				this.label = findMajority(datalist);
			}	
			return this;
		}



		//This is a helper method. Given a datalist, this method returns the label that has the most
		// occurences. In case of a tie it returns the label with the smallest value (numerically) involved in the tie.
		int findMajority(ArrayList<Datum> datalist)
		{
			int l = datalist.get(0).x.length;
			int [] votes = new int[l];

			//loop through the data and count the occurrences of datapoints of each label
			for (Datum data : datalist)
			{
				votes[data.y]+=1;
			}
			int max = -1;
			int max_index = -1;
			//find the label with the max occurrences
			for (int i = 0 ; i < l ;i++)
			{
				if (max<votes[i])
				{
					max = votes[i];
					max_index = i;
				}
			}
			return max_index;
		}




		// This method takes in a datapoint (excluding the label) in the form of an array of type double (Datum.x) and
		// returns its corresponding label, as determined by the decision tree
		int classifyAtNode(double[] xQuery) {
			//YOUR CODE HERE
			if(leaf) {
				return label;
			}else {
				if(xQuery[attribute] < threshold) {
					return left.classifyAtNode(xQuery);
				}else {
					return right.classifyAtNode(xQuery);
				}
			}
		}


		//given another DTNode object, this method checks if the tree rooted at the calling DTNode is equal to the tree rooted
		//at DTNode object passed as the parameter
		public boolean equals(DTNode dt2)
		{
			
			//YOUR CODE HERE
				// traversal (preorder) of each node is the same. Base case for leaf
			if(dt2 == null) {
				return false;
			}
			
			if(leaf) {
				return label == dt2.label;
			}
			if(threshold == dt2.threshold && attribute == dt2.attribute) {
				return ((left.equals(dt2.left) || (left == null && dt2.left == null)) && (right.equals(dt2.right) || (right == null && dt2.right == null)));
				}
			return false;
		}
	}



	//Given a dataset, this retuns the entropy of the dataset
	double calcEntropy(ArrayList<Datum> datalist)
	{
		double entropy = 0;
		double px = 0;
		float [] counter= new float[2];
		if (datalist.size()==0)
			return 0;
		double num0 = 0.00000001,num1 = 0.000000001;

		//calculates the number of points belonging to each of the labels
		for (Datum d : datalist)
		{
			counter[d.y]+=1;
		}
		//calculates the entropy using the formula specified in the document
		for (int i = 0 ; i< counter.length ; i++)
		{
			if (counter[i]>0)
			{
				px = counter[i]/datalist.size();
				entropy -= (px*Math.log(px)/Math.log(2));
			}
		}

		return entropy;
	}


	// given a datapoint (without the label) calls the DTNode.classifyAtNode() on the rootnode of the calling DecisionTree object
	int classify(double[] xQuery ) {
		DTNode node = this.rootDTNode;
		return node.classifyAtNode( xQuery );
	}

    // Checks the performance of a DecisionTree on a dataset
    //  This method is provided in case you would like to compare your
    //results with the reference values provided in the PDF in the Data
    //section of the PDF

    String checkPerformance( ArrayList<Datum> datalist)
	{
		DecimalFormat df = new DecimalFormat("0.000");
		float total = datalist.size();
		float count = 0;

		for (int s = 0 ; s < datalist.size() ; s++) {
			double[] x = datalist.get(s).x;
			int result = datalist.get(s).y;
			if (classify(x) != result) {
				count = count + 1;
			}
		}

		return df.format((count/total));
	}


	//Given two DecisionTree objects, this method checks if both the trees are equal by
	//calling onto the DTNode.equals() method
	public static boolean equals(DecisionTree dt1,  DecisionTree dt2)
	{
		boolean flag = true;
		flag = dt1.rootDTNode.equals(dt2.rootDTNode);
		return flag;
	}

}
